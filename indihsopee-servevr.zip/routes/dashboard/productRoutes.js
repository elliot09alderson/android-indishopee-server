const router = require("express").Router();
const { authMiddleware } = require("../../middlewares/authMiddleware");
const productController = require("../../controllers/dashboard/productController");

router.post("/product-add", authMiddleware, productController.add_product);
router.get("/products-get", authMiddleware, productController.products_get);
router.get(
  "/product-get/:productId",
  authMiddleware,
  productController.product_get
);
router.delete(
  "/product-delete/:productId",
  authMiddleware,
  productController.product_delete
);
router.post(
  "/product-update",
  authMiddleware,
  productController.product_update
);
router.post(
  "/product-image-update",
  authMiddleware,
  productController.product_image_update
);

/**
 *
 *
 *   @ANDROID
 *
 */

router.post("/product/sponsor/:productId", productController.addSponsorship);

module.exports = router;
